package com.example.quizz;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.quizz.model.pythonques;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Python extends AppCompatActivity {

    TextView q1;
    RadioButton r1, r2, r3, r4;
    Button submitBtn;

    List<pythonques> questionList = new ArrayList<>();
    int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_python);

        // Initialize views
        q1 = findViewById(R.id.q1);
        r1 = findViewById(R.id.r1);
        r2 = findViewById(R.id.r2);
        r3 = findViewById(R.id.r3);
        r4 = findViewById(R.id.r4);
        submitBtn = findViewById(R.id.b);

        // ✅ Load questions from the JSON file
        loadQuestionsFromJsonFile();

        // ✅ Handle submit button click
        submitBtn.setOnClickListener(v -> {
            String selectedAnswer = "";

            if (r1.isChecked()) selectedAnswer = r1.getText().toString();
            else if (r2.isChecked()) selectedAnswer = r2.getText().toString();
            else if (r3.isChecked()) selectedAnswer = r3.getText().toString();
            else if (r4.isChecked()) selectedAnswer = r4.getText().toString();

            if (!selectedAnswer.isEmpty()) {
                if (selectedAnswer.equals(questionList.get(currentIndex).getAnswer())) {
                    Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Wrong!", Toast.LENGTH_SHORT).show();
                }

                currentIndex++;
                if (currentIndex < questionList.size()) {
                    showQuestion(currentIndex);
                } else {
                    Toast.makeText(this, "Quiz Finished!", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ✅ New method to load and parse the JSON file
    private void loadQuestionsFromJsonFile() {
        try {
            // Read the JSON file from the assets folder
            InputStream is = getAssets().open("python.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, StandardCharsets.UTF_8);

            // Parse the JSON string into a List of pythonques objects using Gson
            Gson gson = new Gson();
            Type listType = new TypeToken<ArrayList<pythonques>>() {}.getType();
            questionList = gson.fromJson(json, listType);

            if (questionList != null && !questionList.isEmpty()) {
                showQuestion(currentIndex);
            } else {
                Toast.makeText(Python.this, "No questions found in JSON!", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(Python.this, "Error loading JSON file!", Toast.LENGTH_SHORT).show();
        }
    }


    private void showQuestion(int index) {
        pythonques q = questionList.get(index);
        q1.setText(q.getQuestion());
        r1.setText(q.getOptions().get(0));
        r2.setText(q.getOptions().get(1));
        r3.setText(q.getOptions().get(2));
        r4.setText(q.getOptions().get(3));
        r1.setChecked(false);
        r2.setChecked(false);
        r3.setChecked(false);
        r4.setChecked(false);
    }
}